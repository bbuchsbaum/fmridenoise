# ND-X Core Data Structures
# This file will define S3/R6 classes for:
# - fMRI data objects (wrapping NIfTI images, metadata)
# - Design matrix objects
# - ND-X parameter objects

# Placeholder for now 